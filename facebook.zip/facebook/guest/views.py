from django.shortcuts import render
from django.http import HttpResponse

def index(request):

	return HttpResponse("<h1>Welcome in Guest Book </h1>")

def sqr(request):
	num =5
	s = num*num
	c = s*num
	return HttpResponse("Square is "+str(s) + " Cube is "+str(c) + "Result is ="+ str(type(num).__name__))


def home(request):
    return render(request,"guest/hello.html")	